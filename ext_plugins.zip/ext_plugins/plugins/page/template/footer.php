        <!-- <script src="<?php echo base_url(); ?>theme2/js/jquery-1.11.1.min.js"></script> -->
        <script src="<?php echo base_url(); ?>theme2/js/jquery-migrate-1.2.1.min.js"></script>
        <script src="<?php echo base_url(); ?>theme2/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url(); ?>theme2/js/modernizr.min.js"></script>
        <script src="<?php echo base_url(); ?>theme2/js/pace.min.js"></script>
        <script src="<?php echo base_url(); ?>theme2/js/retina.min.js"></script>
        <script src="<?php echo base_url(); ?>theme2/js/jquery.cookies.js"></script>




        
        <script src="<?php echo base_url(); ?>theme2/js/jquery.prettyPhoto.js"></script>
        <script src="<?php echo base_url(); ?>theme2/js/holder.js"></script>

        <script src="<?php echo base_url(); ?>theme2/js/custom.js"></script>
        <script>
            jQuery(document).ready(function(){
              
              jQuery("a[data-rel^='prettyPhoto']").prettyPhoto();
              
            });
        </script>
