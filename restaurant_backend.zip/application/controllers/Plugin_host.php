<?php 

class Plugin_host extends SUB_Controller{

  
  function index(){
  	// echo __filter('page_bold','loaded') . '<br />';
    // print_r(func_get_args());
    
    $a = func_get_args();
    
    if (count($a) <= 0){
    
     $a = array_merge(array('admin'),$a);
    
    }
    
    $route = implode('/', $a);
    
    env('__history__',$route);

    echo __filter('route',$route);

  }


}