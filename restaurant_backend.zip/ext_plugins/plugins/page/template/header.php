
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" />
<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.js"></script>