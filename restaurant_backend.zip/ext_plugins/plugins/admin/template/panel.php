<div class="col-xs-12" style="
    margin-top: 17px;
">
	<div class="col-xs-12 col-md-3">
		 <?php 
           $menu_config = __action('admin_menu',array(array("Menu","")));
		 ?>
		 <ul class="list-group">
		 	<?php 
             foreach ($menu_config as $k=>$v){
             	if (empty($v[1])){
                 $r = 'active';
             	}else{
             	 $r = '';	
             	}
		 	?>
		 	
	<a class="list-group-item <?php echo $r; ?>" href="<?php echo base_url() . $v[1]; ?>"><?php echo $v[0]; ?></a>
		 	
		 	<?php 
             }
		 	?>

		 	<a class="list-group-item" style="color: red;" href="<?php echo __filter('admin_logout_url'); ?>"><?php echo __filter('admin_logout_text','Signout'); ?></a>
		 </ul>

	</div>


	<div class="col-xs-12 col-md-9" style="border-left: 1px solid #ddd;min-height: 200px;">
	  <?php echo $content; ?>	
	</div>

</div>