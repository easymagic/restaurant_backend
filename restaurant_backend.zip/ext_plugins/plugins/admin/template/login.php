<form method="post" action="<?php echo BASE_URL; ?>actions/launch/admin/login">
<div class="col-xs-12">
	
 


 <div class="col-xs-12 col-md-4 col-md-offset-4" style="margin-top: 40px;">
 	<?php 
      __filter('log_message');
 	?>
 	<div class="panel panel-primary">
 		<div class="panel-heading">
 			<?php echo __filter('admin_login_header'); ?>
 		</div>
 		<div class="panel-body">
 			<div class="col-xs-12">
 				<div class="col-xs-12">
 					<label>
 						E-mail
 					</label>
 				</div>
 				<div class="col-xs-12">
 					<input type="text" name="email" class="form-control" />
 				</div>

 				<div class="col-xs-12">
 					<label>
 						Password
 					</label>
 				</div>
 				<div class="col-xs-12">
 					<input type="password" name="password" class="form-control" />
 				</div>


 			</div>
 		</div>
 		<div class="panel-footer clearfix">
 			<div class="pull-left">
 				<input type="submit" class="btn btn-primary" value="Login" />
 			</div>
 		</div>
 	</div>
 </div>




</div>
</form>
