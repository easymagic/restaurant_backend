<!-- order list -->
<div class="col-xs-12">
	<h3>Created Orders</h3>
</div>

<div class="col-xs-12" align="right">
	
	<select id="filter">
		<option value="">--Filter--</option>
		<option value="">--Reset--</option>
		<option value="2">Pending</option>
		<option value="1">Approved</option>
		<option value="0">Voided</option>
	</select>

	<span>
		<b>Total Amount</b>
	</span>
	<span>
		=N=<?php echo number_format($total->total_price); ?>
	</span>
,
	<span>
		<b>Total Qty.</b>
	</span>
	<span>
		<?php echo number_format($qty->total_qty); ?>
	</span>

</div>


<div class="col-xs-12">
	<?php 
      __filter('log_message');
	?>
</div>


<div class="col-xs-12">
	<table class="table">
		<tr>
			<th>
				Customer Name
			</th>
			<th>
				Qty.
			</th>
			<th>
				Price
			</th>
			<th>
				Payment Type 
			</th>
			<th>
				Amount Tendered
			</th>
			<th>
				Status
			</th>
			<th>
				Date Created
			</th>
		</tr>
		<?php 
         foreach ($items as $k=>$v){

         	?>
            
            <tr>
            	<td>
            		<?php echo $v->customer_name; ?>
            	</td>
            	<td>
            		<?php echo $v->total_qty; ?>
            	</td>
            	<td>
            		<?php echo $v->total_price; ?>
            	</td>

            	<td>
            		<?php echo $v->payment_type; ?>
            	</td>

            	<td>
            		<?php echo $v->amount_tendered; ?>
            	</td>

            	<td>
            		<?php echo __filter('order_status',$v->status); ?>
            	</td>

            	<td>
            		<?php 
                      echo $v->date_created;
            		?>
            	</td>

            	<td>

            		<?php 
                      if ($v->status == 2){
                    ?>
            		<a href="<?php echo base_url(); ?>actions/launch/order/approve/<?php echo $v->id; ?>" class="btn btn-sm btn-success">Confirm</a>
            		<a href="<?php echo base_url(); ?>actions/launch/order/void/<?php echo $v->id; ?>" class="btn btn-sm btn-warning">Void</a>
                    <?php 
                      }
            		?>


            		<a href="" class="btn btn-info">Detail</a>
            		
            	</td>
            </tr>

         	<?php 

         }
		?>
	</table>
</div>

<div class="col-xs-12" align="center" style="padding: 11px;">
<?php 

if ($page == 1) {
   echo " FIRST PREV ";
} else {
   echo ' <a class="btn btn-default btn-sm" href="' . base_url() . 'order/list/1" >FIRST</a> ';
   $prevpage = $page-1;
   echo ' <a class="btn btn-default btn-sm" href="' . base_url() . 'order/list/' . $prevpage . '" >PREV</a> ';

   // echo " <a href='{$_SERVER['PHP_SELF']}?pageno=$prevpage'>PREV</a> ";
} // if

echo " ( Page $page of $lastpage ) ";


if ($page == $lastpage) {
   echo " NEXT LAST ";
} else {
   $nextpage = $page+1;
   echo ' <a class="btn btn-default btn-sm" href="' . base_url() . 'order/list/' . $nextpage . '" >NEXT</a> ';
   echo ' <a class="btn btn-default btn-sm" href="' . base_url() . 'order/list/' . $lastpage . '" >LAST</a> ';

   // echo " <a href='{$_SERVER['PHP_SELF']}?pageno=$nextpage'>NEXT</a> ";
   // echo " <a href='{$_SERVER['PHP_SELF']}?pageno=$lastpage'>LAST</a> ";
} // if




?>	
</div>
<script type="text/javascript">
	(function($){

		$(function(){

           $('#filter').on('change',function(){
           	location.href = '<?php echo base_url(); ?>actions/launch/order/save_filter/status/' + $(this).val();
           });

		});

	})(jQuery);
</script>